using Terraria.ModLoader;

namespace mitsuasiamod
{
	class mitsuasiamod : Mod
	{
		public mitsuasiamod()
		{
		}
	}
}
